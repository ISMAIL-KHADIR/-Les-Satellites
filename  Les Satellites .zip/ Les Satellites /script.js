document.querySelector('.toggle-arrow').addEventListener('click', function () {
  const text = document.querySelector('.content p');
  const arrow = this.querySelector('span');
  
  // تبديل عرض الفقرة
  if (text.style.display === 'block') {
    text.style.display = 'none';
    arrow.textContent = '^';
  } else {
    text.style.display = 'block';
    arrow.textContent = '×';
  }
});